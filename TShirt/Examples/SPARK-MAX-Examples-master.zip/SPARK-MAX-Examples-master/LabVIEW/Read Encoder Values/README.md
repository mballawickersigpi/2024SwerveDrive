## Running
In this example, encoder values are read in Periodic Tasks.vi

![alt text](https://github.com/REVrobotics/SPARK-MAX-Examples/blob/master/LabVIEW/Read%20Encoder%20Values/Output.PNG "Output")
