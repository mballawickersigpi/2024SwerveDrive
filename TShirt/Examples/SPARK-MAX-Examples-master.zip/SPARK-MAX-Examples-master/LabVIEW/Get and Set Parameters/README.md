## Running
In this example, parameters are set and read in Periodic Tasks.vi

![alt text](https://github.com/REVrobotics/SPARK-MAX-Examples/blob/master/LabVIEW/Get%20and%20Set%20Parameters/Output.PNG "Output")
