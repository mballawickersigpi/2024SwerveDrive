## Running
In this example, position (in units of revolutions) is set and read in Periodic Tasks.vi

![alt text](https://github.com/REVrobotics/SPARK-MAX-Examples/blob/master/LabVIEW/Position%20Closed%20Loop%20Control/Output.PNG "Output")
