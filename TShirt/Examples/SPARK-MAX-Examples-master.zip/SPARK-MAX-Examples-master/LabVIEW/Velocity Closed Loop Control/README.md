## Running
In this example, velocity is set and read in Periodic Tasks.vi

![alt text](https://github.com/REVrobotics/SPARK-MAX-Examples/blob/master/LabVIEW/Velocity%20Closed%20Loop%20Control/Output.PNG "Output")
