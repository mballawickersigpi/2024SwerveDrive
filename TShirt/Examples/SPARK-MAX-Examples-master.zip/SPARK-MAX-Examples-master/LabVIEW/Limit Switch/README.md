## Running
In this example, Limit Switch parameters are set in Periodic Tasks.vi

![alt text](https://github.com/REVrobotics/SPARK-MAX-Examples/blob/master/LabVIEW/Limit%20Switch/Output.PNG "Output")
